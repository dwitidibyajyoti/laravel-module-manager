<?php

namespace Modules\FormSubmit\Database\Seeders;

use Illuminate\Database\Seeder;

class FormSubmitDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
