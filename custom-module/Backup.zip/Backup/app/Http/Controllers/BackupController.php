<?php

namespace Modules\Backup\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class BackupController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('backup::index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create() {}

    /**
     * Store a newly created resource in storage.
     */
    public function store()
    {
        $connection = config('database.default');
        $db = config("database.connections.{$connection}");

        if (!file_exists(storage_path('backups'))) {
            mkdir(storage_path('backups'), 0755, true);
        }

        $fileName = 'dbbackup.sql';
        $filePath = storage_path("backups/{$fileName}");

        if ($connection === 'sqlite') {
            $sourcePath = $db['database'];
            // Log::info('SQLite Source Path: ' . $db['database']);
            if (!file_exists($sourcePath)) {
                return response()->json(['success' => false, 'message' => 'SQLite database not found.']);
            }

            if (!copy($sourcePath, $filePath)) {
                return response()->json(['success' => false, 'message' => 'Failed to copy SQLite DB.']);
            }

            return response()->json(['success' => true, 'message' => 'SQLite backup created.', 'path' => $filePath]);
        }

        if ($connection === 'mysql') {
            $command = sprintf(
                'mysqldump --user=%s --password=%s --host=%s --port=%s %s > %s',
                escapeshellarg($db['username']),
                escapeshellarg($db['password']),
                escapeshellarg($db['host']),
                escapeshellarg($db['port'] ?? 3306),
                escapeshellarg($db['database']),
                escapeshellarg($filePath)
            );

            exec($command, $output, $resultCode);

            if ($resultCode !== 0) {
                return response()->json(['success' => false, 'message' => 'MySQL backup failed.']);
            }

            return response()->json(['success' => true, 'message' => 'MySQL backup created.', 'path' => $filePath]);
        }

        return response()->json(['success' => false, 'message' => 'Unsupported DB connection: ' . $connection]);
    }




    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        $path = storage_path('backups/dbbackup.sql');

        if (!file_exists($path)) {
            return response()->json(['message' => 'Backup not found.'], 404);
        }

        return response()->download($path, 'dbbackup.sql');
    }

    public function download()
    {
        $path = storage_path('backups/dbbackup.sql');

        if (!file_exists($path)) {
            return response()->json(['message' => 'Backup not found.'], 404);
        }

        return response()->download($path, 'dbbackup.sql');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        return view('backup::edit');
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id) {}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id) {}
}
