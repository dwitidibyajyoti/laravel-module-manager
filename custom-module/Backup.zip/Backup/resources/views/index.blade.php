<x-backup::layouts.master>
    <h1 class="text-xl font-bold mb-4">Database Backup</h1>

    <p>Module: {!! config('backup.name') !!}</p>

    <div class="flex items-center gap-4 mt-6">
        <button onclick="createBackup()" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded">
            Create Backup
        </button>

        <button onclick="downloadBackup()"
            class="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded">
            Download Latest Backup
        </button>
    </div>

    <script>
        function createBackup() {
            fetch('{{ route('backup.store') }}', {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        'Accept': 'application/json'
                    }
                })
                .then(res => res.json())
                .then(data => alert(data.message || 'Backup created!'))
                .catch(err => alert('Backup failed.'));
        }

        function downloadBackup() {
            window.open('{{ route('backup.download') }}', '_blank');
        }
    </script>
</x-backup::layouts.master>
