<?php

namespace Modules\Backup\Database\Seeders;

use Illuminate\Database\Seeder;

class BackupDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
