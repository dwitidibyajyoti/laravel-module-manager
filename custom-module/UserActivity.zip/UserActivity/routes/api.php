<?php

use Illuminate\Support\Facades\Route;
use Modules\UserActivity\Http\Controllers\UserActivityController;

Route::middleware(['auth:sanctum'])->prefix('v1')->group(function () {
    Route::apiResource('useractivities', UserActivityController::class)->names('useractivity');
});
