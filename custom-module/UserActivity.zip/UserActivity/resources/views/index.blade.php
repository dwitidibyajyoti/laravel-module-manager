<x-useractivity::layouts.master>
    <h1 class="text-2xl font-bold mb-4">🧾 User Activity</h1>

    <table class="min-w-full bg-white border border-gray-300 rounded shadow">
        <thead class="bg-gray-100 text-left">
            <tr>
                <th class="py-2 px-4 border-b">User</th>
                <th class="py-2 px-4 border-b">IP Address</th>
                <th class="py-2 px-4 border-b">Device</th>
                <th class="py-2 px-4 border-b">Login At</th>
                <th class="py-2 px-4 border-b">Logout At</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($activities as $activity)
                <tr>
                    <td class="py-2 px-4 border-b">{{ $activity->user->name ?? 'N/A' }}</td>
                    <td class="py-2 px-4 border-b">{{ $activity->ip_address }}</td>
                    <td class="py-2 px-4 border-b">{{ $activity->device }}</td>
                    <td class="py-2 px-4 border-b">{{ $activity->login_at }}</td>
                    <td class="py-2 px-4 border-b">{{ $activity->logout_at ?? 'Still Logged In' }}</td>
                </tr>
            @empty
                <tr>
                    <td colspan="5" class="py-3 px-4 text-center text-gray-500">No activity found.</td>
                </tr>
            @endforelse
        </tbody>
    </table>

    <div class="mt-4">
        {{ $activities->links() }}
    </div>
</x-useractivity::layouts.master>
