<?php

namespace Modules\UserActivity\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Modules\UserActivity\Database\Factories\LoginActivityFactory;

class LoginActivity extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'ip_address',
        'device',
        'login_at',
        'logout_at',
    ];

    public function user()
    {
        return $this->belongsTo(\App\Models\User::class);
    }
}

















// Modules/UserActivity/Entities/LoginActivity.php

namespace Modules\UserActivity\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class LoginActivity extends Model {}
