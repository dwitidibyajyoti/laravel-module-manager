<?php

namespace Modules\UserActivity\Providers;

use Illuminate\Support\ServiceProvider;

use Illuminate\Auth\Events\Login;
use Illuminate\Auth\Events\Logout;
use Illuminate\Support\Facades\Event;
// use Modules\UserActivity\Entities\LoginActivity;
use Modules\UserActivity\Models\LoginActivity as ModelsLoginActivity;

class AuthEventServiceProvider extends ServiceProvider
{
    /**
     * Register the service provider.
     */
    public function register(): void {}

    /**
     * Get the services provided by the provider.
     */
    public function provides(): array
    {
        return [];
    }

    public function boot()
    {
        Event::listen(Login::class, function ($event) {
            ModelsLoginActivity::create([
                'user_id' => $event->user->id,
                'ip_address' => request()->ip(),
                'device' => request()->userAgent(),
                'login_at' => now(),
            ]);
        });

        Event::listen(Logout::class, function ($event) {
            ModelsLoginActivity::where('user_id', $event->user->id)
                ->whereNull('logout_at')
                ->latest()
                ->first()?->update([
                    'logout_at' => now()
                ]);
        });
    }
}
