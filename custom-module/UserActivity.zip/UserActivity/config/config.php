<?php

return [
    'name' => 'UserActivity',
];
